# DayTrader 3 - Architecture Analysis

## Overview

DayTrader 3 is a **modular monolithic** Java EE 6 application that demonstrates best practices for enterprise Java development. While packaged as a single EAR (Enterprise Archive), it exhibits clear modular boundaries and follows a traditional n-tier architecture pattern.

## Architectural Style

### Classification: Modular Monolith
- **Deployment Model**: Single EAR file containing multiple modules
- **Module Structure**: 3 separate WAR/JAR modules within the EAR
  - EJB Module (dt-ejb.jar) - Business logic and data access
  - Web Module (web.war) - Web UI and servlets
  - REST Module (Rest.war) - RESTful services
- **Runtime**: All modules run within a single application server instance (WebSphere Liberty)
- **Data Store**: Single shared database (Apache Derby)

### Key Characteristics
1. **Monolithic Deployment**: All components deployed together as one unit
2. **Modular Design**: Clear separation between modules with defined interfaces
3. **Shared Resources**: Common database, transaction context, and security context
4. **Synchronous Communication**: Direct method calls between layers
5. **Asynchronous Messaging**: JMS for specific operations (order processing)

## Architecture Layers

### 1. Client Layer
- **Web Browsers**: Access the main trading application
- **REST Clients**: Consume RESTful services
- **Load Testing Tools**: Use performance testing servlets

### 2. Presentation Layer (Web Module)
Components in the web tier handle user interaction and request processing:

- **Main Application Servlets**
  - `TradeAppServlet`: Primary trading interface (`/app`)
  - `TradeConfigServlet`: Configuration management (`/config`)
  - `TradeScenarioServlet`: Testing scenarios (`/scenario`)
  
- **JSF Components**
  - `AccountBean`: JSF managed bean for account operations
  - `QuoteBean`: JSF managed bean for quote operations
  
- **Web Infrastructure**
  - `OrdersAlertFilter`: Servlet filter for order alerts
  - `TradeWebContextListener`: Application lifecycle management
  
- **Performance Testing** 
  - 31 specialized servlets for performance benchmarking
  - Test various Java EE features (JDBC, JPA, EJB, JMS)

### 3. Business Logic Layer (EJB Module)
The core business logic is implemented using Enterprise JavaBeans:

- **Service Interfaces**
  - `TradeServices`: Core business operations interface
  - `TradeWSServices`: Web service variant of TradeServices
  
- **Service Implementations**
  - `TradeSLSBBean`: Primary stateless session bean using JPA
  - `DirectSLSBBean`: Alternative implementation using direct JDBC
  - `TradeDirect`: Direct JDBC implementation class
  
- **Service Locator**
  - `TradeAction`: Facade that routes requests to appropriate implementation
  - Supports runtime switching between JPA and JDBC modes

### 4. Integration Layer
Asynchronous processing through Java Message Service:

- **Message-Driven Beans**
  - `DTBroker3MDB`: Processes buy/sell orders from TradeBrokerQueue
  - `DTStreamer3MDB`: Streams quote updates via TradeStreamerTopic
  
- **JMS Destinations**
  - Queue: TradeBrokerQueue (point-to-point for orders)
  - Topic: TradeStreamerTopic (publish-subscribe for quotes)

### 5. Data Access Layer
Persistence is handled through JPA 2.0 with an alternative JDBC path:

- **JPA Entities**
  - `AccountDataBean`: User account information
  - `AccountProfileDataBean`: User profile details
  - `HoldingDataBean`: Stock holdings
  - `OrderDataBean`: Buy/sell orders
  - `QuoteDataBean`: Stock quotes
  
- **Direct JDBC Components**
  - `TradeDirect`: JDBC-based data access
  - `KeySequenceDirect`: Primary key generation for JDBC mode

### 6. REST Services Layer (REST Module)
A separate module provides RESTful web services:

- **JAX-RS Components**
  - `AddressApplication`: JAX-RS application configuration
  - `AddressBook`: REST resource for address management
  - `AddressBookDatabase`: In-memory data store

## Design Patterns Identified

### 1. **Service Locator Pattern**
- **Implementation**: `TradeAction` class
- **Purpose**: Abstracts the lookup and creation of business services
- **Benefits**: Decouples web tier from EJB lookups, supports multiple runtime modes

### 2. **Session Facade Pattern**
- **Implementation**: `TradeSLSBBean` and `DirectSLSBBean`
- **Purpose**: Provides a unified interface to business operations
- **Benefits**: Reduces network calls, manages transactions, simplifies client access

### 3. **Data Access Object (DAO) Pattern**
- **Implementation**: JPA entities with EntityManager
- **Alternative**: `TradeDirect` for JDBC access
- **Benefits**: Abstracts data persistence, allows switching between JPA and JDBC

### 4. **Message-Driven Bean Pattern**
- **Implementation**: `DTBroker3MDB`, `DTStreamer3MDB`
- **Purpose**: Asynchronous processing of orders and market updates
- **Benefits**: Improves scalability, decouples order processing

### 5. **Factory Pattern**
- **Implementation**: `ObjectFactory` in REST module
- **Purpose**: Creates JAXB objects for XML processing
- **Benefits**: Centralizes object creation

### 6. **Singleton Pattern (Implicit)**
- **Implementation**: Stateless session beans, message-driven beans
- **Container-managed**: EJB container manages bean lifecycle
- **Benefits**: Resource efficiency, thread safety

### 7. **Transfer Object Pattern**
- **Implementation**: `MarketSummaryDataBean`, `MarketSummaryDataBeanWS`
- **Purpose**: Transfers data between layers
- **Benefits**: Reduces network overhead, provides data aggregation

## Dependencies and Coupling Analysis

### Inter-Module Dependencies

```
Web Module ──depends on──> EJB Module
    │
    └──> Uses TradeAction to access business services
    └──> References JPA entities for data display
    └──> Accesses TradeConfig for configuration

REST Module ──independent──> (Self-contained)
    │
    └──> No dependencies on other modules
    └──> Demonstrates module isolation

EJB Module ──depends on──> Data Store
    │
    └──> JPA entities mapped to database tables
    └──> Direct JDBC connections
    └──> JMS for asynchronous messaging
```

### Coupling Assessment

1. **Loose Coupling**
   - Web tier coupled to business interfaces, not implementations
   - REST module completely decoupled from other modules
   - JMS provides temporal decoupling for order processing

2. **Tight Coupling Areas**
   - JPA entities used directly in web tier (data coupling)
   - Shared database schema creates structural coupling
   - TradeConfig used globally (common coupling)

3. **Configuration Coupling**
   - All modules share TradeConfig for runtime settings
   - JNDI names hardcoded in multiple places
   - Database configuration shared across modules

### External Dependencies

1. **Java EE 6 APIs**
   - Servlet 3.0, EJB 3.1, JPA 2.0, JAX-RS 1.1
   - JMS 1.1, JSF 2.0, Bean Validation 1.0

2. **Application Server**
   - WebSphere Liberty-specific features
   - JNDI namespace assumptions
   - Container-managed transactions and security

3. **Database**
   - Apache Derby embedded database
   - SQL assumptions in JDBC code
   - JPA provider (EclipseLink/OpenJPA)

## Architecture Characteristics

### Strengths
1. **Clear Separation of Concerns**: Each layer has distinct responsibilities
2. **Standards-Based**: Uses Java EE 6 standards throughout
3. **Multiple Access Modes**: Supports both JPA and JDBC for flexibility
4. **Performance Testing Built-in**: Comprehensive benchmarking capabilities
5. **Asynchronous Processing**: JMS for scalable order handling

### Weaknesses
1. **Monolithic Deployment**: All changes require full redeployment
2. **Shared Database**: Creates coupling between components
3. **Limited Scalability**: Can only scale vertically as a unit
4. **Technology Lock-in**: Tied to Java EE application server
5. **Synchronous Processing**: Most operations are blocking

### Opportunities for Improvement
1. **Microservices Migration**: Natural module boundaries support decomposition
2. **API Gateway**: Could front the existing services
3. **Event-Driven Architecture**: Extend JMS usage for more operations
4. **Caching Layer**: Add distributed cache for quotes and market data
5. **Cloud-Native Features**: Containerization, service mesh, observability

## Architectural Diagram

The complete system architecture is visualized in the Mermaid diagram at:
[System Architecture Diagram](../diagrams/system-architecture.mmd)

The diagram illustrates:
- All major components and their relationships
- Data flow between layers
- Synchronous (solid lines) and asynchronous (dotted lines) communication
- Module boundaries and deployment units
- Integration with external systems (database, JMS)

## Summary

DayTrader 3 represents a well-structured modular monolith that follows Java EE best practices. While monolithic in deployment, its modular design and clear architectural layers provide a solid foundation for modernization. The use of standard Java EE APIs and design patterns makes it a good candidate for migration to microservices or cloud-native architectures.