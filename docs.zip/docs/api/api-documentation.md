# DayTrader 3 - API and Interface Documentation

## Overview

DayTrader 3 provides multiple interfaces for accessing its functionality:
- **Web Interface**: Traditional servlet-based web application
- **REST API**: JAX-RS based RESTful services (limited demo implementation)
- **Internal Java Interfaces**: Service interfaces for business operations
- **JMS Integration**: Asynchronous messaging for order processing

## API Types Summary

| API Type | Implementation | Purpose | Status |
|----------|---------------|---------|--------|
| REST | JAX-RS 1.1 | Address book demo service | Limited demo |
| Web/HTTP | Servlets 3.0 | Main trading application | Full implementation |
| JMS | Message-Driven Beans | Asynchronous order processing | Full implementation |
| Java Interfaces | EJB Local/Remote | Internal service contracts | Full implementation |

## 1. REST API Endpoints

### Base URL
```
http://<server>:<port>/daytrader3/rest
```

### Address Book Service

#### 1.1 Get All Addresses
- **Endpoint**: `/addresses`
- **Method**: `GET`
- **Response**: JSON
- **Description**: Retrieves all addresses from the in-memory database
- **Response Format**:
```json
{
  "addresses": [
    {
      "entryName": "string",
      "zipCode": "string",
      "streetAddress": "string",
      "city": "string",
      "state": "string",
      "country": "string"
    }
  ]
}
```

#### 1.2 Search Addresses
- **Endpoint**: `/addresses/search/{searchstring}`
- **Method**: `GET`
- **Path Parameters**: 
  - `searchstring`: String to match against entry names (prefix match)
- **Response**: JSON
- **Description**: Returns addresses where entryName starts with searchstring
- **Response Format**: Same as Get All Addresses

#### 1.3 Get Specific Address
- **Endpoint**: `/addresses/{entryName}`
- **Method**: `GET`
- **Path Parameters**:
  - `entryName`: Unique identifier for the address
- **Response**: XML or JSON (based on Accept header)
- **Description**: Returns a specific address by its entry name
- **Response Format** (XML):
```xml
<address>
  <entryName>string</entryName>
  <zipCode>string</zipCode>
  <streetAddress>string</streetAddress>
  <city>string</city>
  <state>string</state>
  <country>string</country>
</address>
```

## 2. Web Application Endpoints (Servlet-based)

### Base URL
```
http://<server>:<port>/daytrader3
```

### 2.1 Main Application Servlet (`/app`)

The TradeAppServlet handles all trading operations through form-based HTTP requests:

#### Authentication Operations

##### Login
- **URL**: `/app?action=login`
- **Method**: `POST`
- **Parameters**:
  - `uid`: User ID
  - `passwd`: Password
  - `inScenario`: (optional) Scenario mode flag
- **Response**: Redirects to portfolio page on success

##### Logout
- **URL**: `/app?action=logout`
- **Method**: `POST`
- **Response**: Redirects to welcome page

##### Register
- **URL**: `/app?action=register`
- **Method**: `POST`
- **Parameters**:
  - `user id`: New user ID
  - `passwd`: Password
  - `confirm passwd`: Password confirmation
  - `Full Name`: User's full name
  - `Credit Card Number`: Credit card for account
  - `money`: Initial balance
  - `email`: Email address
  - `snail mail`: Physical address
- **Response**: Redirects to login on success

#### Trading Operations

##### Buy Stock
- **URL**: `/app?action=buy`
- **Method**: `POST`
- **Parameters**:
  - `symbol`: Stock symbol
  - `quantity`: Number of shares
- **Session Required**: Yes
- **Response**: Order confirmation page

##### Sell Stock
- **URL**: `/app?action=sell`
- **Method**: `POST`
- **Parameters**:
  - `holdingID`: ID of holding to sell
- **Session Required**: Yes
- **Response**: Order confirmation page

##### Get Quote
- **URL**: `/app?action=quotes&symbols=<symbol>`
- **Method**: `GET`
- **Parameters**:
  - `symbols`: Comma-separated stock symbols
- **Response**: Quote display page

#### Account Management

##### View Portfolio
- **URL**: `/app?action=portfolio`
- **Method**: `GET`
- **Session Required**: Yes
- **Response**: Portfolio holdings page

##### View Account
- **URL**: `/app?action=account`
- **Method**: `GET`
- **Session Required**: Yes
- **Response**: Account information page

##### Update Profile
- **URL**: `/app?action=update_profile`
- **Method**: `POST`
- **Parameters**:
  - `password`: New password
  - `cpassword`: Confirm password
  - `fullname`: Full name
  - `address`: Address
  - `creditcard`: Credit card
  - `email`: Email
- **Session Required**: Yes
- **Response**: Updated account page

### 2.2 Configuration Servlet (`/config`)

Manages application configuration and database operations:

##### Reset Database
- **URL**: `/config?action=resetTrade`
- **Method**: `POST`
- **Response**: Confirmation page

##### Build Database
- **URL**: `/config?action=buildDB`
- **Method**: `POST`
- **Response**: Database creation status

##### Set Configuration
- **URL**: `/config?action=setConfig`
- **Method**: `POST`
- **Parameters**: Various configuration parameters
- **Response**: Updated configuration page

### 2.3 Scenario Servlet (`/scenario`)

Automated testing interface for running trading scenarios.

## 3. Internal Java Interfaces

### 3.1 TradeServices Interface

Core business operations interface with three implementations:
- `TradeSLSBBean`: EJB implementation using JPA
- `DirectSLSBBean`: EJB implementation using direct JDBC
- `TradeDirect`: POJO implementation with direct JDBC

#### Key Methods:

##### Market Operations
```java
MarketSummaryDataBean getMarketSummary() throws Exception
```
- Returns current market conditions including TSIA index

##### Trading Operations
```java
OrderDataBean buy(String userID, String symbol, double quantity, int orderProcessingMode) throws Exception
OrderDataBean sell(String userID, Integer holdingID, int orderProcessingMode) throws Exception
void queueOrder(Integer orderID, boolean twoPhase) throws Exception
OrderDataBean completeOrder(Integer orderID, boolean twoPhase) throws Exception
void cancelOrder(Integer orderID, boolean twoPhase) throws Exception
```

##### Account Management
```java
AccountDataBean login(String userID, String password) throws Exception
void logout(String userID) throws Exception
AccountDataBean register(String userID, String password, String fullname, 
                        String address, String email, String creditcard, 
                        BigDecimal openBalance) throws Exception
```

##### Portfolio Operations
```java
Collection<?> getHoldings(String userID) throws Exception
HoldingDataBean getHolding(Integer holdingID) throws Exception
Collection<?> getOrders(String userID) throws Exception
Collection<?> getClosedOrders(String userID) throws Exception
```

##### Quote Operations
```java
QuoteDataBean getQuote(String symbol) throws Exception
Collection getAllQuotes() throws Exception
QuoteDataBean createQuote(String symbol, String companyName, BigDecimal price) throws Exception
QuoteDataBean updateQuotePriceVolume(String symbol, BigDecimal newPrice, double sharesTraded) throws Exception
```

### 3.2 Local EJB Interfaces

#### TradeSLSBLocal
- Local interface for JPA-based implementation
- Extends TradeServices interface
- Used for container-managed transactions

#### DirectSLSBLocal  
- Local interface for JDBC-based implementation
- Extends TradeServices interface
- Alternative implementation for performance comparison

## 4. JMS Integration Points

### 4.1 Message Queues

#### TradeBrokerQueue
- **Type**: Point-to-Point Queue
- **Purpose**: Order processing queue
- **Producer**: TradeSLSBBean (buy/sell operations)
- **Consumer**: DTBroker3MDB
- **Message Format**: TextMessage with order ID
- **Properties**:
  - `command`: "neworder"
  - `orderID`: Integer order identifier
  - `symbol`: Stock symbol
  - `userid`: User placing order
  - `twoPhase`: Transaction mode flag

### 4.2 Message Topics

#### TradeStreamerTopic
- **Type**: Publish-Subscribe Topic
- **Purpose**: Real-time quote updates
- **Publisher**: TradeSLSBBean (quote updates)
- **Subscribers**: DTStreamer3MDB
- **Message Format**: TextMessage
- **Properties**:
  - `command`: "updateQuote" or "ping"
  - `symbol`: Stock symbol
  - `price`: Current price
  - `oldPrice`: Previous price
  - `publishTime`: Timestamp

## 5. Integration Points

### 5.1 Database Connections
- **Primary**: Apache Derby embedded database
- **Access Methods**:
  - JPA 2.0 via persistence unit "daytrader"
  - Direct JDBC via configured DataSource
- **Connection Pool**: Container-managed

### 5.2 External System Interfaces
- None identified - DayTrader is self-contained

### 5.3 Authentication/Security
- Container-managed security
- Form-based authentication
- Session-based state management
- No external identity providers

## 6. Performance Testing Endpoints

DayTrader includes 31 primitive testing servlets under `/servlet/` for benchmarking:

### Examples:
- `/servlet/PingServlet` - Basic servlet response time
- `/servlet/PingServlet2Jsp` - Servlet to JSP forward
- `/servlet/PingServlet2DB` - Database connectivity
- `/servlet/PingServlet2Session` - Session management
- `/servlet/PingServlet2Entity` - JPA entity access
- `/servlet/PingServlet2MDBQueue` - JMS queue messaging

## 7. API Security

### Authentication Requirements
- **REST API**: No authentication (demo only)
- **Web Application**: Form-based login required for trading operations
- **JMS**: Container-managed security
- **EJB**: Container-managed security with role-based access

### Session Management
- HTTP session-based for web application
- Stateless for REST endpoints
- Container-managed for EJB and JMS

## 8. Error Handling

### HTTP Error Codes
- `401 Unauthorized`: Login required
- `404 Not Found`: Invalid endpoint
- `500 Internal Server Error`: Application errors

### Application Exceptions
- Custom exceptions for business logic errors
- Logged via TradeLog utility
- User-friendly error pages for web interface

## Summary

DayTrader 3's API architecture reflects its role as a Java EE 6 demonstration application:
- The main functionality is exposed through a traditional servlet-based web interface
- REST support is minimal (address book demo only)
- Core business logic is encapsulated in well-defined Java interfaces
- JMS provides asynchronous processing capabilities
- The architecture supports multiple implementation strategies (JPA vs JDBC)

The lack of comprehensive REST APIs indicates this is a legacy application that would benefit from API modernization as part of any migration effort.