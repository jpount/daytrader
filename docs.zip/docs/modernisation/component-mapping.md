# DayTrader 3 - Legacy to Modern Component Mapping

## Executive Summary

This document provides a comprehensive mapping of DayTrader 3's Java EE 6 components to their modern Spring Boot equivalents. Each mapping includes migration complexity ratings, code examples, and specific considerations. The mappings follow industry best practices and leverage Spring Boot's convention-over-configuration approach to simplify the codebase while maintaining functionality.

## Technology Mapping Table

### Core Framework Components

| Legacy Component | Modern Equivalent | Complexity | Notes |
|-----------------|-------------------|------------|-------|
| **Java EE 6** | Spring Boot 3.2.x | Medium | Complete platform migration |
| **EJB 3.1** | Spring Services + @Transactional | Medium | Simpler annotation-based approach |
| **JPA 2.0** | Spring Data JPA 3.x | Low | Minor API changes, improved repositories |
| **Servlets 3.0** | Spring MVC REST Controllers | Medium | RESTful design required |
| **JSF 2.0** | React/Angular + REST API | High | Complete UI rewrite |
| **JSP 2.1** | Thymeleaf or SPA | High | Template engine or full SPA |
| **JMS 1.1** | Spring JMS or Spring Cloud Stream | Medium | Similar concepts, better abstraction |
| **JTA 1.1** | Spring Transaction Management | Low | Declarative transactions |
| **JNDI** | Spring Dependency Injection | Low | Cleaner, type-safe injection |
| **web.xml** | Spring Boot Configuration | Low | Java-based configuration |

### Infrastructure Components

| Legacy Component | Modern Equivalent | Complexity | Notes |
|-----------------|-------------------|------------|-------|
| **WebSphere Liberty** | Embedded Tomcat/Jetty | Low | Bundled with Spring Boot |
| **server.xml** | application.yml/properties | Low | Centralized configuration |
| **EAR packaging** | JAR with embedded server | Low | Simplified deployment |
| **WAR modules** | Spring Boot modules | Medium | Restructuring required |
| **Apache Derby** | PostgreSQL/MySQL | Medium | Schema migration needed |
| **Container-managed security** | Spring Security | High | Complete security overhaul |

## Code Pattern Transformations

### 1. EJB to Spring Service

**Legacy EJB Pattern:**
```java
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class TradeSLSBBean implements TradeSLSBLocal {
    
    @PersistenceContext(unitName = "daytrader")
    private EntityManager entityManager;
    
    @Resource(name = "jms/TradeBrokerQueue")
    private Queue tradeBrokerQueue;
    
    @EJB
    private TradeSLSBLocal tradeSLSB;
    
    public OrderDataBean buy(String userID, String symbol, double quantity, int orderProcessingMode) {
        // Business logic
    }
}
```

**Modern Spring Pattern:**
```java
@Service
@Transactional
@Slf4j
public class TradeService {
    
    private final AccountRepository accountRepository;
    private final OrderRepository orderRepository;
    private final KafkaTemplate<String, OrderEvent> kafkaTemplate;
    
    @Autowired
    public TradeService(AccountRepository accountRepository, 
                       OrderRepository orderRepository,
                       KafkaTemplate<String, OrderEvent> kafkaTemplate) {
        this.accountRepository = accountRepository;
        this.orderRepository = orderRepository;
        this.kafkaTemplate = kafkaTemplate;
    }
    
    public OrderDTO buy(String userID, String symbol, double quantity, OrderProcessingMode mode) {
        // Business logic with better error handling
    }
}
```

### 2. Entity Bean Modernization

**Legacy JPA Entity:**
```java
@Entity(name = "orderejb")
@Table(name = "orderejb")
@NamedQueries({
    @NamedQuery(name = "orderejb.findByUser", 
                query = "SELECT o FROM orderejb o WHERE o.account.profile.userID = :userID")
})
public class OrderDataBean implements Serializable {
    @Id
    @Column(name = "ORDERID")
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "orderIdGen")
    private Integer orderID;
    
    // Getters and setters
}
```

**Modern Spring Data Entity:**
```java
@Entity
@Table(name = "orders")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "account_id", nullable = false)
    private Account account;
    
    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private OrderType orderType;
    
    // Lombok handles getters/setters
}

// Repository interface
@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByAccountUserId(String userId);
    
    @Query("SELECT o FROM Order o WHERE o.account.user.id = :userId AND o.orderStatus = :status")
    Page<Order> findUserOrdersByStatus(@Param("userId") String userId, 
                                       @Param("status") OrderStatus status, 
                                       Pageable pageable);
}
```

### 3. Servlet to REST Controller

**Legacy Servlet Pattern:**
```java
@WebServlet(name = "TradeAppServlet", urlPatterns = { "/app" })
public class TradeAppServlet extends HttpServlet {
    
    protected void doPost(HttpServletRequest req, HttpServletResponse res) 
            throws ServletException, IOException {
        String action = req.getParameter("action");
        
        if (action.equals("buy")) {
            String symbol = req.getParameter("symbol");
            String quantity = req.getParameter("quantity");
            // Process and forward to JSP
            req.setAttribute("orderData", orderData);
            getServletContext().getRequestDispatcher("/trade_confirm.jsp")
                .forward(req, res);
        }
    }
}
```

**Modern REST Controller:**
```java
@RestController
@RequestMapping("/api/v1/trades")
@Validated
@Slf4j
public class TradeController {
    
    private final TradeService tradeService;
    
    @PostMapping("/orders")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<OrderResponse> createOrder(@Valid @RequestBody CreateOrderRequest request,
                                                    @AuthenticationPrincipal UserDetails user) {
        log.info("Creating order for user: {} symbol: {}", user.getUsername(), request.getSymbol());
        
        OrderDTO order = tradeService.buy(
            user.getUsername(),
            request.getSymbol(),
            request.getQuantity(),
            request.getOrderMode()
        );
        
        return ResponseEntity
            .created(URI.create("/api/v1/trades/orders/" + order.getId()))
            .body(OrderResponse.from(order));
    }
    
    @ExceptionHandler(InsufficientFundsException.class)
    public ResponseEntity<ErrorResponse> handleInsufficientFunds(InsufficientFundsException e) {
        return ResponseEntity
            .status(HttpStatus.BAD_REQUEST)
            .body(ErrorResponse.of("INSUFFICIENT_FUNDS", e.getMessage()));
    }
}
```

### 4. Message-Driven Bean to Event Listener

**Legacy MDB Pattern:**
```java
@MessageDriven(mappedName = "jms/TradeBrokerQueue", activationConfig = {
    @ActivationConfigProperty(propertyName = "acknowledgeMode", 
                             propertyValue = "Auto-acknowledge"),
    @ActivationConfigProperty(propertyName = "destinationType", 
                             propertyValue = "javax.jms.Queue")
})
public class DTBroker3MDB implements MessageListener {
    
    @EJB
    private TradeSLSBLocal tradeSLSB;
    
    public void onMessage(Message message) {
        try {
            TextMessage textMessage = (TextMessage) message;
            String orderID = textMessage.getStringProperty("orderID");
            // Process order
        } catch (JMSException e) {
            // Handle error
        }
    }
}
```

**Modern Event Listener:**
```java
@Component
@Slf4j
public class OrderEventListener {
    
    private final OrderProcessingService orderProcessingService;
    
    @KafkaListener(topics = "order-events", groupId = "order-processing-group")
    @Retryable(value = {Exception.class}, maxAttempts = 3, backoff = @Backoff(delay = 1000))
    public void handleOrderEvent(@Payload OrderEvent event, 
                                @Header(KafkaHeaders.RECEIVED_TOPIC) String topic) {
        log.info("Processing order event: {} from topic: {}", event.getOrderId(), topic);
        
        try {
            orderProcessingService.processOrder(event);
        } catch (Exception e) {
            log.error("Failed to process order: {}", event.getOrderId(), e);
            throw e; // Trigger retry
        }
    }
    
    @DltHandler
    public void handleDltEvent(@Payload OrderEvent event) {
        log.error("Order sent to DLT: {}", event.getOrderId());
        // Handle dead letter
    }
}
```

### 5. JSF to React Components

**Legacy JSF Pattern:**
```xml
<h:form id="buyForm">
    <h:outputLabel for="symbol" value="Symbol:"/>
    <h:inputText id="symbol" value="#{quoteBean.symbol}" required="true"/>
    
    <h:outputLabel for="quantity" value="Quantity:"/>
    <h:inputText id="quantity" value="#{quoteBean.quantity}" required="true">
        <f:validateLongRange minimum="1" maximum="1000"/>
    </h:inputText>
    
    <h:commandButton value="Buy" action="#{quoteBean.buy}"/>
</h:form>
```

**Modern React Pattern:**
```jsx
import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useMutation } from '@tanstack/react-query';
import { createOrder } from '../api/trading';

export function BuyOrderForm() {
    const { register, handleSubmit, formState: { errors } } = useForm();
    const [isSubmitting, setIsSubmitting] = useState(false);
    
    const orderMutation = useMutation({
        mutationFn: createOrder,
        onSuccess: (data) => {
            toast.success(`Order ${data.orderId} created successfully`);
        },
        onError: (error) => {
            toast.error(error.message);
        }
    });
    
    const onSubmit = async (data) => {
        setIsSubmitting(true);
        await orderMutation.mutateAsync(data);
        setIsSubmitting(false);
    };
    
    return (
        <form onSubmit={handleSubmit(onSubmit)} className="order-form">
            <div className="form-group">
                <label htmlFor="symbol">Symbol</label>
                <input
                    {...register("symbol", { required: "Symbol is required" })}
                    type="text"
                    className={errors.symbol ? 'error' : ''}
                />
                {errors.symbol && <span className="error-message">{errors.symbol.message}</span>}
            </div>
            
            <div className="form-group">
                <label htmlFor="quantity">Quantity</label>
                <input
                    {...register("quantity", {
                        required: "Quantity is required",
                        min: { value: 1, message: "Minimum quantity is 1" },
                        max: { value: 1000, message: "Maximum quantity is 1000" }
                    })}
                    type="number"
                    className={errors.quantity ? 'error' : ''}
                />
                {errors.quantity && <span className="error-message">{errors.quantity.message}</span>}
            </div>
            
            <button type="submit" disabled={isSubmitting}>
                {isSubmitting ? 'Processing...' : 'Buy'}
            </button>
        </form>
    );
}
```

## Data Access Migration

### 1. Direct JDBC to Spring Data JPA

**Legacy JDBC Pattern:**
```java
private OrderDataBean getOrderData(Connection conn, Integer orderID) throws Exception {
    PreparedStatement stmt = getStatement(conn, getOrderSQL);
    stmt.setInt(1, orderID.intValue());
    ResultSet rs = stmt.executeQuery();
    
    OrderDataBean orderData = null;
    if (rs.next()) {
        orderData = new OrderDataBean(
            rs.getInt("orderID"),
            rs.getString("orderType"),
            rs.getString("orderStatus"),
            rs.getTimestamp("openDate"),
            rs.getTimestamp("completionDate"),
            rs.getDouble("quantity"),
            rs.getBigDecimal("price"),
            rs.getBigDecimal("orderFee"),
            rs.getString("quote_symbol")
        );
    }
    rs.close();
    stmt.close();
    return orderData;
}
```

**Modern Spring Data Pattern:**
```java
// Repository interface - no implementation needed
@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    Optional<Order> findById(Long orderId);
    
    @Modifying
    @Query("UPDATE Order o SET o.status = :status, o.completionDate = :date WHERE o.id = :orderId")
    int updateOrderStatus(@Param("orderId") Long orderId, 
                         @Param("status") OrderStatus status, 
                         @Param("date") LocalDateTime date);
}

// Service usage
@Service
@Transactional(readOnly = true)
public class OrderService {
    private final OrderRepository orderRepository;
    
    public OrderDTO getOrder(Long orderId) {
        return orderRepository.findById(orderId)
            .map(OrderMapper::toDTO)
            .orElseThrow(() -> new OrderNotFoundException(orderId));
    }
}
```

### 2. Query Modernization

**Legacy Named Queries:**
```java
@NamedQueries({
    @NamedQuery(
        name = "orderejb.findByUser",
        query = "SELECT o FROM orderejb o WHERE o.account.profile.userID = :userID ORDER BY o.orderID DESC"
    ),
    @NamedQuery(
        name = "orderejb.findOpenOrders",
        query = "SELECT o FROM orderejb o WHERE o.orderStatus = 'open'"
    )
})
```

**Modern Spring Data Queries:**
```java
@Repository
public interface OrderRepository extends JpaRepository<Order, Long>, JpaSpecificationExecutor<Order> {
    
    // Derived query methods
    List<Order> findByAccountUserIdOrderByIdDesc(String userId);
    List<Order> findByOrderStatus(OrderStatus status);
    
    // Custom queries with pagination
    @Query("SELECT o FROM Order o JOIN FETCH o.account a WHERE a.userId = :userId")
    Page<Order> findByUserIdWithAccount(@Param("userId") String userId, Pageable pageable);
    
    // Dynamic queries using Specifications
    default Page<Order> findOrders(OrderSearchCriteria criteria, Pageable pageable) {
        Specification<Order> spec = Specification.where(null);
        
        if (criteria.getUserId() != null) {
            spec = spec.and((root, query, cb) -> 
                cb.equal(root.get("account").get("userId"), criteria.getUserId()));
        }
        
        if (criteria.getStatus() != null) {
            spec = spec.and((root, query, cb) -> 
                cb.equal(root.get("orderStatus"), criteria.getStatus()));
        }
        
        return findAll(spec, pageable);
    }
}
```

### 3. Connection Management

**Legacy Pattern:**
```java
@Resource(name = "jdbc/TradeDataSource")
private DataSource dataSource;

private Connection getConn() throws Exception {
    Connection conn = dataSource.getConnection();
    conn.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
    return conn;
}

// Manual connection management
Connection conn = null;
try {
    conn = getConn();
    // Do work
    conn.commit();
} catch (Exception e) {
    if (conn != null) conn.rollback();
    throw e;
} finally {
    if (conn != null) conn.close();
}
```

**Modern Spring Pattern:**
```yaml
# application.yml
spring:
  datasource:
    url: jdbc:postgresql://localhost:5432/daytrader
    username: ${DB_USERNAME}
    password: ${DB_PASSWORD}
    hikari:
      maximum-pool-size: 20
      minimum-idle: 5
      connection-timeout: 30000
      idle-timeout: 600000
      max-lifetime: 1800000
      
  jpa:
    properties:
      hibernate:
        default_batch_fetch_size: 16
        jdbc:
          batch_size: 25
        order_inserts: true
        order_updates: true
```

```java
// Connection management is automatic
@Service
@Transactional
public class TradeService {
    // No manual connection handling needed
    // Spring manages transactions and connections
}
```

## Configuration Migration

### 1. XML to Java Configuration

**Legacy web.xml:**
```xml
<web-app>
    <servlet>
        <servlet-name>TradeAppServlet</servlet-name>
        <servlet-class>com.ibm.websphere.samples.daytrader.web.TradeAppServlet</servlet-class>
        <init-param>
            <param-name>configFile</param-name>
            <param-value>/WEB-INF/trade-config.xml</param-value>
        </init-param>
    </servlet>
    
    <servlet-mapping>
        <servlet-name>TradeAppServlet</servlet-name>
        <url-pattern>/app</url-pattern>
    </servlet-mapping>
    
    <filter>
        <filter-name>OrdersAlertFilter</filter-name>
        <filter-class>com.ibm.websphere.samples.daytrader.web.OrdersAlertFilter</filter-class>
    </filter>
</web-app>
```

**Modern Spring Configuration:**
```java
@Configuration
@EnableWebMvc
@ComponentScan("com.example.daytrader")
public class WebConfig implements WebMvcConfigurer {
    
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new OrderAlertInterceptor())
                .addPathPatterns("/api/orders/**");
    }
    
    @Override
    public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
        Jackson2ObjectMapperBuilder builder = new Jackson2ObjectMapperBuilder()
            .indentOutput(true)
            .dateFormat(new SimpleDateFormat("yyyy-MM-dd"))
            .modulesToInstall(new JavaTimeModule());
        converters.add(new MappingJackson2HttpMessageConverter(builder.build()));
    }
}
```

### 2. Environment-Specific Configuration

**Legacy Approach:**
```java
// Hard-coded in TradeConfig.java
public static String DATASOURCE = "java:comp/env/jdbc/TradeDataSource";
public static String JMS_QUEUE_CF = "java:comp/env/jms/TradeBrokerQCF";
public static boolean DEBUG = false;
```

**Modern Spring Profiles:**
```yaml
# application.yml
spring:
  profiles:
    active: ${SPRING_PROFILES_ACTIVE:dev}

---
# application-dev.yml
spring:
  config:
    activate:
      on-profile: dev
      
logging:
  level:
    com.example.daytrader: DEBUG
    
app:
  features:
    async-processing: false
    cache-enabled: false

---
# application-prod.yml
spring:
  config:
    activate:
      on-profile: prod
      
logging:
  level:
    com.example.daytrader: INFO
    
app:
  features:
    async-processing: true
    cache-enabled: true
```

### 3. Secrets Management

**Legacy Pattern:**
```xml
<!-- server.xml -->
<dataSource id="DefaultDataSource" jndiName="jdbc/TradeDataSource">
    <jdbcDriver libraryRef="DerbyLib"/>
    <properties.derby.embedded 
        databaseName="${shared.resource.dir}/data/tradedb" 
        createDatabase="create" 
        user="trade" 
        password="trade"/>
</dataSource>
```

**Modern Secrets Management:**
```yaml
# application.yml - no secrets
spring:
  datasource:
    url: ${DATABASE_URL}
    username: ${DATABASE_USERNAME}
    password: ${DATABASE_PASSWORD}
  
  security:
    oauth2:
      client:
        registration:
          google:
            client-id: ${GOOGLE_CLIENT_ID}
            client-secret: ${GOOGLE_CLIENT_SECRET}
```

```bash
# Use environment variables or secret management tools
export DATABASE_PASSWORD=$(vault kv get -field=password secret/daytrader/db)
export GOOGLE_CLIENT_SECRET=$(vault kv get -field=secret secret/daytrader/oauth/google)
```

## Anti-Pattern Remediation

### 1. God Object Pattern

**Legacy Anti-Pattern:**
```java
// TradeConfig.java - 851 lines doing everything
public class TradeConfig {
    // Configuration constants
    public static String DATASOURCE = "...";
    
    // Business logic
    public static int getMAX_USERS() { ... }
    
    // Runtime state
    private static int accessMode;
    
    // Utility methods
    public static void setPublishQuotePriceChange(boolean bool) { ... }
}
```

**Modern Solution:**
```java
// Separate configuration properties
@Component
@ConfigurationProperties(prefix = "app.trading")
@Validated
public class TradingProperties {
    @Min(1)
    private int maxUsers = 200;
    
    @NotNull
    private AccessMode accessMode = AccessMode.STANDARD;
    
    // Getters/setters with validation
}

// Separate feature flags
@Component
public class FeatureFlags {
    @Value("${app.features.publish-quote-changes:true}")
    private boolean publishQuoteChanges;
}

// Separate business constants
public final class TradingConstants {
    public static final int MAX_HOLDINGS_PER_USER = 100;
    public static final BigDecimal MINIMUM_ORDER_VALUE = new BigDecimal("10.00");
    
    private TradingConstants() {} // Prevent instantiation
}
```

### 2. Primitive Obsession

**Legacy Anti-Pattern:**
```java
// Everything is a String
public OrderDataBean buy(String userID, String symbol, double quantity, int orderProcessingMode) {
    // No type safety
}
```

**Modern Solution:**
```java
// Rich domain types
public record UserId(String value) {
    public UserId {
        Assert.hasText(value, "User ID cannot be empty");
    }
}

public record Symbol(String value) {
    public Symbol {
        Assert.hasText(value, "Symbol cannot be empty");
        Assert.isTrue(value.matches("^[A-Z]{1,5}$"), "Invalid symbol format");
    }
}

public record Quantity(BigDecimal value) {
    public Quantity {
        Assert.notNull(value, "Quantity cannot be null");
        Assert.isTrue(value.compareTo(BigDecimal.ZERO) > 0, "Quantity must be positive");
    }
}

public enum OrderProcessingMode {
    SYNCHRONOUS,
    ASYNCHRONOUS,
    ASYNC_TWO_PHASE
}

// Type-safe service method
public Order buy(UserId userId, Symbol symbol, Quantity quantity, OrderProcessingMode mode) {
    // Compile-time type safety
}
```

### 3. Copy-Paste Programming

**Legacy Anti-Pattern:**
```java
// Duplicate error handling everywhere
try {
    // Some operation
} catch (Exception e) {
    Log.error(e, "TradeServletAction.doLogin(...)", "Error logging in user");
    throw new ServletException("TradeServletAction.doLogin(...)" +
        " exception logging in user " + userID + " with password " + password, e);
}
```

**Modern Solution:**
```java
// Centralized exception handling
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {
    
    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<ErrorResponse> handleBusinessException(BusinessException e) {
        log.error("Business error: {}", e.getMessage(), e);
        return ResponseEntity
            .status(e.getStatus())
            .body(ErrorResponse.of(e.getCode(), e.getMessage()));
    }
    
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleUnexpected(Exception e) {
        log.error("Unexpected error", e);
        return ResponseEntity
            .status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(ErrorResponse.of("INTERNAL_ERROR", "An unexpected error occurred"));
    }
}

// Clean service code
@Service
public class TradeService {
    public Order createOrder(CreateOrderRequest request) {
        // Just throw domain exceptions, handler does the rest
        if (account.getBalance().compareTo(orderValue) < 0) {
            throw new InsufficientFundsException(account.getId(), orderValue);
        }
    }
}
```

## Best Practice Adoption

### 1. Dependency Injection

**Legacy Pattern:**
```java
// Direct instantiation and lookups
TradeServices tAction = new TradeAction();
Context ctx = new InitialContext();
DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/TradeDataSource");
```

**Modern Pattern:**
```java
// Constructor injection
@Service
@RequiredArgsConstructor
public class TradeService {
    private final AccountRepository accountRepository;
    private final OrderRepository orderRepository;
    private final EventPublisher eventPublisher;
    
    // Dependencies injected automatically
}
```

### 2. Immutability

**Legacy Mutable Entities:**
```java
public class OrderDataBean {
    private Integer orderID;
    private String orderType;
    
    public void setOrderID(Integer orderID) {
        this.orderID = orderID;
    }
    // Many setters
}
```

**Modern Immutable DTOs:**
```java
@Value
@Builder
public class OrderDTO {
    Long id;
    OrderType type;
    OrderStatus status;
    Instant createdAt;
    BigDecimal amount;
    
    // No setters, immutable after creation
}
```

### 3. Functional Programming

**Legacy Imperative:**
```java
Collection<OrderDataBean> orders = getOrders(userID);
ArrayList<OrderDataBean> openOrders = new ArrayList<OrderDataBean>();
for (OrderDataBean order : orders) {
    if (order.getOrderStatus().equals("open")) {
        openOrders.add(order);
    }
}
```

**Modern Functional:**
```java
List<OrderDTO> openOrders = orderRepository.findByUserId(userId).stream()
    .filter(order -> order.getStatus() == OrderStatus.OPEN)
    .map(OrderMapper::toDTO)
    .collect(Collectors.toList());
```

## Migration Complexity Summary

### Low Complexity Migrations (1-2 days each)
- JPA entity annotations
- Basic dependency injection
- Configuration externalization
- Simple REST endpoints
- Transaction annotations

### Medium Complexity Migrations (3-5 days each)
- EJB to Spring Service conversion
- JMS to Spring Integration/Kafka
- Servlet to REST controller
- Database migration scripts
- Security configuration

### High Complexity Migrations (1-2 weeks each)
- JSF to React/Angular conversion
- Stateful to stateless architecture
- Container-managed to Spring Security
- Performance optimization
- Distributed transaction handling

## Conclusion

This component mapping provides a clear path from Java EE 6 to Spring Boot, with specific examples and patterns for each type of component. The migration complexity varies by component type, but following these mappings and best practices will result in a more maintainable, testable, and scalable application. Teams should prioritize security fixes and low-complexity migrations for quick wins, while planning adequate time for high-complexity UI and architectural changes.