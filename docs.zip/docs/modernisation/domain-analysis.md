# DayTrader 3 - Domain Boundaries and Strangler Fig Analysis

## Executive Summary

DayTrader 3 is a modular monolith with clear domain boundaries that make it suitable for strangler fig extraction. The application consists of five primary domains with varying levels of coupling and extraction complexity. The Trading Operations domain presents the highest business value but also the most complexity, while the Market Data and User Management domains offer easier extraction paths as initial targets.

## Domain Discovery

### Package Organization Analysis

The codebase follows a technical layer-based package structure:
- `com.ibm.websphere.samples.daytrader` - Core business entities and services
- `com.ibm.websphere.samples.daytrader.ejb3` - EJB implementations
- `com.ibm.websphere.samples.daytrader.direct` - Direct JDBC implementations
- `com.ibm.websphere.samples.daytrader.web` - Web tier servlets and controllers
- `com.ibm.websphere.samples.daytrader.rest` - REST API (limited address book demo)
- `com.ibm.websphere.samples.daytrader.util` - Utility classes

While organized by technical layers rather than business domains, clear business boundaries emerge through analysis of the data model and operations.

## Identified Domains

### 1. User Management Domain

**Core Business Purpose**: Handle user registration, authentication, and profile management

**Key Entities**:
- AccountProfileDataBean (User Profile)
- AccountDataBean (User Account)

**Primary Operations**:
- User registration
- Login/logout authentication
- Profile management (update email, address, etc.)
- Password management

**Database Tables**:
- ACCOUNTPROFILEEJB
- ACCOUNTEJB (partial - account metadata only)

**API Endpoints**:
- `/app/login`
- `/app/logout`
- `/app/register`
- `/app/update_profile`

**Dependencies on Other Domains**:
- None (self-contained for authentication)
- Account balance managed by Trading domain

### 2. Market Data Domain

**Core Business Purpose**: Manage stock quotes and market information

**Key Entities**:
- QuoteDataBean (Stock Quote)
- MarketSummaryDataBean (Market Overview)

**Primary Operations**:
- Get stock quotes
- Update quote prices
- Calculate market summary/indices
- Retrieve all quotes

**Database Tables**:
- QUOTEEJB

**API Endpoints**:
- `/app/quotes`
- `/app/marketSummary`
- Limited REST: `/rest/api/addresses` (demo only)

**Dependencies on Other Domains**:
- Used by Trading for order pricing
- Used by Portfolio for current valuations

### 3. Trading Operations Domain

**Core Business Purpose**: Execute buy/sell orders and manage transactions

**Key Entities**:
- OrderDataBean (Trade Order)
- Related: Account balance updates

**Primary Operations**:
- Buy stocks
- Sell stocks
- Queue orders (async via JMS)
- Complete orders
- Cancel orders
- Order status tracking

**Database Tables**:
- ORDEREJB
- ACCOUNTEJB (balance updates)
- KEYGENEJB (ID generation)

**API Endpoints**:
- `/app/buy`
- `/app/sell`
- `/app/order`

**Dependencies on Other Domains**:
- Requires Market Data for pricing
- Updates Portfolio holdings
- Updates User account balances
- Heavy coupling through transactions

### 4. Portfolio Management Domain

**Core Business Purpose**: Track user stock holdings and portfolio value

**Key Entities**:
- HoldingDataBean (Stock Holding)

**Primary Operations**:
- View holdings
- Calculate portfolio value
- Track purchase history
- Holdings created/removed by Trading

**Database Tables**:
- HOLDINGEJB

**API Endpoints**:
- `/app/portfolio`
- `/app/holdings`

**Dependencies on Other Domains**:
- Created/modified by Trading
- Uses Market Data for valuations
- Linked to User accounts

### 5. Platform Services Domain

**Core Business Purpose**: Provide technical capabilities and performance testing

**Key Entities**:
- RunStatsDataBean
- Various Ping test entities

**Primary Operations**:
- Performance primitives
- Database testing
- JMS testing
- Configuration management
- Statistics tracking

**Database Tables**:
- Various test tables
- Configuration storage

**API Endpoints**:
- `/app/config`
- `/app/prims/*` (numerous test endpoints)

**Dependencies on Other Domains**:
- Cross-cutting concerns
- Can be mostly eliminated in modernization

## Coupling Assessment

### Domain Coupling Matrix

| Domain | User Mgmt | Market Data | Trading | Portfolio | Platform |
|--------|-----------|-------------|---------|-----------|----------|
| User Management | - | None | Low | Low | Low |
| Market Data | None | - | Medium | Medium | Low |
| Trading Operations | Low | Medium | - | High | Low |
| Portfolio Management | Low | Medium | High | - | Low |
| Platform Services | Low | Low | Low | Low | - |

### Coupling Details

#### High Coupling: Trading ↔ Portfolio
- Shared database transactions
- Order completion creates/modifies holdings
- Sell orders require holding validation
- Difficult to separate without eventual consistency

#### Medium Coupling: Trading/Portfolio → Market Data
- Read-only dependency for pricing
- Can be decoupled via API calls
- No shared transactions

#### Low Coupling: User Management
- Authentication can be externalized
- Account balance is only coupling point
- Natural boundary for extraction

## Extraction Difficulty Rating

### 1. Market Data Domain: **EASY**
- **Isolation**: High - read-mostly service
- **Data Entanglement**: Low - single table
- **UI Complexity**: Low - simple display
- **Business Criticality**: Medium - needed for operations

### 2. User Management Domain: **EASY**
- **Isolation**: High - clear boundaries
- **Data Entanglement**: Low - two related tables
- **UI Complexity**: Low - standard forms
- **Business Criticality**: High - but standard patterns

### 3. Platform Services Domain: **EASY**
- **Isolation**: Very High - test utilities
- **Data Entanglement**: None
- **UI Complexity**: Low
- **Business Criticality**: Low - can be removed

### 4. Portfolio Management Domain: **MEDIUM**
- **Isolation**: Medium - coupled to trading
- **Data Entanglement**: Medium - foreign keys to orders
- **UI Complexity**: Medium - portfolio displays
- **Business Criticality**: High

### 5. Trading Operations Domain: **HARD**
- **Isolation**: Low - core of the system
- **Data Entanglement**: High - multi-table transactions
- **UI Complexity**: High - complex workflows
- **Business Criticality**: Very High - revenue generating

## Recommended Extraction Order

### Phase 1: Quick Wins (3-6 months)
1. **Platform Services** - Remove/reduce footprint
2. **Market Data** - Extract as microservice
3. **User Management** - Externalize to identity provider

### Phase 2: Portfolio Extraction (6-9 months)
4. **Portfolio Management** - Decouple from trading via events

### Phase 3: Core Modernization (9-18 months)
5. **Trading Operations** - Gradual extraction with careful transaction management

## Domain-Specific Extraction Strategies

### Market Data Domain Extraction

**Pattern**: API Gateway with Cache
- Create REST API for quote services
- Implement caching layer for performance
- Route legacy calls through gateway
- No data migration needed (read-only)

**Synchronization**: Not required (source of truth remains)

**API Facade**:
```
GET /api/v1/quotes/{symbol}
GET /api/v1/quotes
GET /api/v1/market-summary
WebSocket /api/v1/quotes/stream
```

**Migration Steps**:
1. Create new quote service with same data source
2. Implement REST API with caching
3. Add API gateway routing
4. Update web tier to use new API
5. Migrate direct database access
6. Consider external market data feeds

**Rollback**: Route traffic back to monolith

### User Management Domain Extraction

**Pattern**: Identity Provider Integration
- Implement standard protocols (OAuth2/OIDC)
- Migrate to external identity service
- Keep profile data synchronized

**Synchronization**: 
- Initial data migration
- Webhook updates for profile changes
- JWT tokens for session management

**API Facade**:
```
POST /auth/login
POST /auth/logout
POST /auth/register
GET /api/v1/profile
PUT /api/v1/profile
```

**Migration Steps**:
1. Select identity provider (Keycloak, Auth0, etc.)
2. Migrate user credentials (with reset required)
3. Implement JWT validation in monolith
4. Update login/logout flows
5. Sync profile updates via events
6. Remove legacy authentication code

**Rollback**: Dual authentication support

### Portfolio Management Domain Extraction

**Pattern**: Event Sourcing with CQRS
- Separate read model for portfolio views
- Event-driven updates from trading
- Maintain data consistency via sagas

**Synchronization**:
- Event stream from trading operations
- Materialized views for portfolio data
- Compensation for failed trades

**API Facade**:
```
GET /api/v1/portfolio/{userId}
GET /api/v1/holdings/{userId}
GET /api/v1/holdings/{holdingId}
WebSocket /api/v1/portfolio/updates
```

**Migration Steps**:
1. Implement event publishing in trading
2. Create portfolio service with event handlers
3. Build materialized view of holdings
4. Implement read API
5. Add real-time updates via WebSocket
6. Gradually migrate UI to new service

**Rollback**: Replay events to rebuild state

### Trading Operations Domain Extraction

**Pattern**: Staged Database Decomposition
- Gradual extraction of order management
- Maintain transaction integrity
- Implement distributed sagas

**Synchronization**:
- Two-phase commit initially
- Move to eventual consistency
- Compensating transactions

**API Facade**:
```
POST /api/v1/orders/buy
POST /api/v1/orders/sell
GET /api/v1/orders/{orderId}
GET /api/v1/orders/user/{userId}
PUT /api/v1/orders/{orderId}/cancel
```

**Migration Steps**:
1. Extract order service with shared database
2. Implement API layer over existing logic
3. Add event publishing for order states
4. Create saga orchestration for transactions
5. Gradually move to separate database
6. Implement distributed transaction patterns

**Rollback**: Complex - requires transaction reversal

## Anti-Corruption Layer Design

### Legacy → Modern Translation

**Data Transformations**:
- Decimal types to proper money types
- String statuses to enums
- Flatten nested structures
- Add missing timestamps

**Event Mappings**:
```
Legacy OrderCompleted → OrderExecutedEvent + PortfolioUpdatedEvent
Legacy Login → UserAuthenticatedEvent
Legacy QuoteUpdate → MarketDataUpdatedEvent
```

**API Translation Layer**:
- REST/JSON from legacy servlet/JSP
- Proper HTTP status codes
- Standardized error responses
- OpenAPI documentation

### Temporary Dual-Write Strategies

**Order Creation**:
1. Write to legacy ORDEREJB
2. Publish OrderCreatedEvent
3. New service updates read model
4. Validation via reconciliation job

**Portfolio Updates**:
1. Trading updates legacy HOLDINGEJB
2. Event triggers portfolio service update
3. Compare states periodically
4. Alert on mismatches

**User Profile Sync**:
1. Update in identity provider
2. Webhook updates legacy profile
3. Cache user data in monolith
4. Gradual migration of consumers

## Domain Dependency Diagram

See [Domain Dependencies Diagram](../diagrams/domain-dependencies.mmd)

## Domain Boundaries Diagram

See [Domain Boundaries Diagram](../diagrams/domain-boundaries.mmd)

## Extraction Sequence Timeline

See [Extraction Sequence Diagram](../diagrams/extraction-sequence.mmd)

## Risk Mitigation

### Technical Risks
1. **Transaction Integrity**: Use saga pattern with compensation
2. **Performance Degradation**: Implement caching and connection pooling
3. **Data Consistency**: Event sourcing with snapshots
4. **Integration Complexity**: Comprehensive contract testing

### Business Risks
1. **Service Disruption**: Blue-green deployments with instant rollback
2. **Data Loss**: Event store with full audit trail
3. **User Experience**: Feature flags for gradual rollout
4. **Compliance**: Maintain audit logs across services

## Summary

DayTrader's modular monolith architecture provides clear domain boundaries suitable for strangler fig extraction. Starting with the low-risk Market Data and User Management domains allows the team to establish patterns and infrastructure before tackling the complex Trading-Portfolio coupling. The recommended approach emphasizes maintaining business continuity while progressively modernizing the architecture.