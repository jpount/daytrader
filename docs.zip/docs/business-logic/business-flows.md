# DayTrader 3 - Business Logic and Flow Analysis

## Overview

DayTrader 3 implements a stock trading system with comprehensive business workflows for user management, trading operations, portfolio management, and market data updates. The application follows a traditional servlet-based architecture with both synchronous and asynchronous processing modes for order execution.

## Major Business Processes

### 1. User Management Workflows

#### User Registration
**Entry Point**: `/app/register` → TradeServletAction.doRegister()

**Flow**:
1. User submits registration form
2. Validate input data (all fields required)
3. Check password confirmation match
4. Create user profile (AccountProfileDataBean)
5. Create trading account with initial balance
6. Generate unique account ID
7. Initialize empty portfolio
8. Auto-login after successful registration
9. Forward to home page

**Business Rules**:
- All fields are mandatory
- Passwords must match
- UserID must be unique
- Initial account balance: $10,000 (configurable)

#### User Login
**Entry Point**: `/app/login` → TradeServletAction.doLogin()

**Flow**:
1. User submits credentials
2. Validate username exists
3. Verify password (plain text comparison)
4. Update login count and timestamp
5. Create HTTP session
6. Load account summary
7. Forward to trading home page

**Error Handling**:
- Invalid credentials → return to welcome page
- Missing user → display error message

#### User Logout
**Entry Point**: `/app/logout` → TradeServletAction.doLogout()

**Flow**:
1. Retrieve user from session
2. Update logout count
3. Invalidate HTTP session
4. Forward to welcome page

### 2. Trading Operations

#### Buy Stock
**Entry Point**: `/app/buy` → TradeServletAction.doBuy()

**Synchronous Flow**:
1. Validate user session
2. Get current quote price
3. Calculate total cost: (quantity × price) + order fee
4. Verify sufficient account balance
5. Debit account balance
6. Create order with status "open"
7. Complete order immediately:
   - Create new holding
   - Update order status to "closed"
   - Link holding to order
8. Return order confirmation

**Asynchronous Flow** (2-Phase Commit):
1. Steps 1-6 same as synchronous
2. Queue order to JMS (TradeBrokerQueue)
3. Return order confirmation (status: "open")
4. MDB processes order:
   - Begin global transaction
   - Complete order creation
   - Create holding
   - Update order status
   - Commit transaction
5. Queue completion notification

**Business Rules**:
- Minimum quantity: 1 share
- Order fee: $15.95 (configurable)
- Balance must cover total cost
- Quote must exist

#### Sell Stock
**Entry Point**: `/app/sell` → TradeServletAction.doSell()

**Synchronous Flow**:
1. Validate user owns holding
2. Get current quote price
3. Calculate proceeds: (quantity × price) - order fee
4. Create sell order (status: "open")
5. Mark holding as "selling"
6. Credit account balance
7. Complete order:
   - Remove holding
   - Update order status to "closed"
8. Return order confirmation

**Asynchronous Flow**:
1. Steps 1-6 same as synchronous
2. Queue order to JMS
3. Return confirmation (status: "open")
4. MDB completes order asynchronously

**Business Rules**:
- Must own the holding
- Cannot sell partial holdings
- Order fee applied to proceeds

### 3. Portfolio Management

#### View Portfolio
**Entry Point**: `/app/portfolio` → TradeServletAction.doPortfolio()

**Flow**:
1. Get all holdings for user
2. For each holding:
   - Get current quote
   - Calculate current value
   - Calculate gain/loss
3. Calculate totals:
   - Total holdings value
   - Total purchase basis
   - Overall gain/loss
4. Display portfolio summary

**Business Rules**:
- Holdings marked "selling" shown separately
- Real-time quote prices used
- No pagination (all holdings loaded)

### 4. Market Operations

#### Get Quote
**Entry Point**: `/app/quotes` → TradeServletAction.doQuotes()

**Flow**:
1. Parse comma-separated symbols
2. For each symbol:
   - Retrieve quote from database
   - Format price display
3. Return quote list

**Business Rules**:
- Symbols are case-insensitive
- Invalid symbols return null
- Multiple symbols supported

#### Market Summary
**Entry Point**: `/app/marketSummary`

**Flow**:
1. Calculate TSIA (Trade Stock Index Average)
   - Sum top 100 stock prices
   - Compare to opening TSIA
2. Get market statistics:
   - Total volume traded
   - Number of trades
3. Find top gainers (limit 5)
4. Find top losers (limit 5)
5. Return market summary

### 5. Order Processing States

#### Order Lifecycle

```
Created → Open → Processing → Closed/Completed
              ↓
              Cancelled
```

**State Transitions**:
- **Created**: Initial state when order is created
- **Open**: Order submitted and payment processed
- **Processing**: Order picked up by broker (async only)
- **Closed**: Order executed, holdings updated
- **Completed**: User acknowledged (alerts cleared)
- **Cancelled**: Order cancelled due to error

**State Management Rules**:
- Orders cannot transition from terminal states
- Cancelled orders trigger balance reversal
- Closed orders trigger alerts for users

### 6. Asynchronous Processing

#### JMS Message Flow

**TradeBrokerQueue** (Order Execution):
1. Buy/Sell orders queued with:
   - Order ID
   - Two-phase commit flag
   - Direct mode flag
   - Timestamp
2. DTBroker3MDB processes:
   - Completes order
   - Updates holdings
   - Handles failures

**TradeStreamerTopic** (Quote Updates):
1. Random quote updates published
2. DTStreamer3MDB processes:
   - Updates quote price
   - Publishes to WebSocket
   - Updates market stats

### 7. Business Rules Summary

#### Account Management
- Initial balance: $10,000
- No overdrafts allowed
- No margin trading
- Single currency (USD)

#### Trading Rules
- Order fee: $15.95 per transaction
- No partial fills
- Market orders only (no limits)
- No short selling
- Holdings are all-or-nothing

#### Security Rules
- Plain text passwords (security issue)
- Session-based authentication
- No authorization roles
- No transaction signing

#### Data Integrity
- Pessimistic locking for accounts
- Two-phase commit for async orders
- No optimistic concurrency control
- Manual transaction management

## Sequence Diagrams

See [Business Flow Diagrams](../diagrams/business-flows.mmd) for detailed sequence diagrams of:
- User Registration Flow
- Buy Order Execution (Sync/Async)
- Sell Order Execution  
- Portfolio Valuation
- Market Summary Calculation

## Error Handling Patterns

### Transaction Rollback
- Database exceptions → rollback
- Insufficient funds → rollback and alert
- Invalid holdings → cancel order
- JMS failures → cancel order

### User Notifications
- Order completion alerts
- Insufficient funds warnings
- Invalid symbol errors
- System error pages

## Performance Considerations

### Caching
- No application-level caching
- Database connection pooling only
- Market summary recalculated each time

### Batch Operations
- No batch order processing
- Individual transaction commits
- No bulk portfolio updates

## Integration Points

### External Systems
- None (self-contained demo)

### Internal Integration
- JMS for async processing
- Direct JDBC as alternative
- Servlet → EJB → Database

## Summary

DayTrader's business logic implements a simplified but complete trading system. While functional for demonstration purposes, it lacks production features like:
- Proper security (encrypted passwords, transaction signing)
- Advanced order types (limit, stop-loss)
- Real-time market data feeds
- Audit trails and compliance logging
- High-frequency trading support

The clear separation between synchronous and asynchronous processing modes provides a good foundation for performance testing and comparison.