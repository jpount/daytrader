# DayTrader 3 - Data Model Analysis

## Overview

DayTrader 3 uses a relational data model implemented with JPA 2.0 (Java Persistence API) on Apache Derby database. The application supports both JPA-based and direct JDBC data access patterns, providing flexibility for performance testing and comparison.

## Data Storage Technologies

### Primary Storage
- **Database**: Apache Derby (embedded mode)
- **Version**: Bundled with WebSphere Liberty
- **Connection Pool**: Container-managed via JNDI
- **Data Sources**:
  - `jdbc/TradeDataSource` - JTA-enabled for transactions
  - `jdbc/NoTxTradeDataSource` - Non-transactional access

### ORM Technology
- **JPA Provider**: Default provider (EclipseLink or OpenJPA)
- **JPA Version**: 2.0
- **Persistence Unit**: "daytrader"
- **Transaction Type**: JTA (container-managed)

### Alternative Access
- **Direct JDBC**: Available through TradeDirect implementation
- **Key Generation**: KEYGENEJB table for sequence management

## Entity Model

### 1. ACCOUNTEJB (Account Entity)
Represents user trading accounts with balance and activity tracking.

| Column | Type | Constraints | Description |
|--------|------|------------|-------------|
| ACCOUNTID | INTEGER | PRIMARY KEY | Auto-generated account identifier |
| LOGINCOUNT | INTEGER | NOT NULL | Number of successful logins |
| LOGOUTCOUNT | INTEGER | NOT NULL | Number of logouts |
| LASTLOGIN | TIMESTAMP | | Last login timestamp |
| CREATIONDATE | TIMESTAMP | | Account creation date |
| BALANCE | DECIMAL(14,2) | | Current account balance |
| OPENBALANCE | DECIMAL(14,2) | | Initial account balance |
| PROFILE_USERID | VARCHAR(250) | FOREIGN KEY | Link to user profile |

**Indexes**: 
- PRIMARY KEY on ACCOUNTID
- INDEX on PROFILE_USERID for profile lookups

### 2. ACCOUNTPROFILEEJB (User Profile Entity)
Stores user profile information and credentials.

| Column | Type | Constraints | Description |
|--------|------|------------|-------------|
| USERID | VARCHAR(250) | PRIMARY KEY | Unique user identifier |
| PASSWD | VARCHAR(250) | | User password (plain text - security issue) |
| FULLNAME | VARCHAR(250) | | User's full name |
| ADDRESS | VARCHAR(250) | | Physical address |
| EMAIL | VARCHAR(250) | | Email address |
| CREDITCARD | VARCHAR(250) | | Credit card information |

### 3. QUOTEEJB (Stock Quote Entity)
Contains current stock quote information.

| Column | Type | Constraints | Description |
|--------|------|------------|-------------|
| SYMBOL | VARCHAR(250) | PRIMARY KEY | Stock symbol |
| COMPANYNAME | VARCHAR(250) | | Company name |
| VOLUME | DOUBLE | NOT NULL | Trading volume |
| PRICE | DECIMAL(14,2) | | Current price |
| OPEN1 | DECIMAL(14,2) | | Opening price |
| LOW | DECIMAL(14,2) | | Daily low |
| HIGH | DECIMAL(14,2) | | Daily high |
| CHANGE1 | DOUBLE | NOT NULL | Price change |

### 4. ORDEREJB (Order Entity)
Tracks buy/sell orders with status and execution details.

| Column | Type | Constraints | Description |
|--------|------|------------|-------------|
| ORDERID | INTEGER | PRIMARY KEY | Auto-generated order ID |
| ORDERTYPE | VARCHAR(250) | | 'buy' or 'sell' |
| ORDERSTATUS | VARCHAR(250) | | Status: open, closed, completed, cancelled |
| OPENDATE | TIMESTAMP | | Order creation timestamp |
| COMPLETIONDATE | TIMESTAMP | | Order completion timestamp |
| QUANTITY | DOUBLE | NOT NULL | Number of shares |
| PRICE | DECIMAL(14,2) | | Execution price |
| ORDERFEE | DECIMAL(14,2) | | Transaction fee |
| ACCOUNT_ACCOUNTID | INTEGER | FOREIGN KEY | Account placing order |
| QUOTE_SYMBOL | VARCHAR(250) | FOREIGN KEY | Stock being traded |
| HOLDING_HOLDINGID | INTEGER | FOREIGN KEY | Resulting holding (for buys) |

**Indexes**:
- PRIMARY KEY on ORDERID
- INDEX on ACCOUNT_ACCOUNTID for account orders
- INDEX on HOLDING_HOLDINGID for holding lookups
- COMPOSITE INDEX on (ACCOUNT_ACCOUNTID, ORDERSTATUS) for closed orders

### 5. HOLDINGEJB (Holdings Entity)
Represents stock holdings in user portfolios.

| Column | Type | Constraints | Description |
|--------|------|------------|-------------|
| HOLDINGID | INTEGER | PRIMARY KEY | Auto-generated holding ID |
| QUANTITY | DOUBLE | NOT NULL | Number of shares held |
| PURCHASEPRICE | DECIMAL(14,2) | | Purchase price per share |
| PURCHASEDATE | TIMESTAMP | | Date of purchase |
| ACCOUNT_ACCOUNTID | INTEGER | FOREIGN KEY | Account owning the holding |
| QUOTE_SYMBOL | VARCHAR(250) | FOREIGN KEY | Stock symbol |

**Indexes**:
- PRIMARY KEY on HOLDINGID
- INDEX on ACCOUNT_ACCOUNTID for portfolio queries

### 6. KEYGENEJB (Key Generation Table)
Manages primary key generation for JDBC mode.

| Column | Type | Constraints | Description |
|--------|------|------------|-------------|
| KEYNAME | VARCHAR(250) | PRIMARY KEY | Entity name ('account', 'order', 'holding') |
| KEYVAL | INTEGER | NOT NULL | Next available key value |

## Entity Relationships

### Relationship Summary
1. **Account ↔ Profile**: One-to-One (mandatory)
2. **Account → Orders**: One-to-Many
3. **Account → Holdings**: One-to-Many  
4. **Quote → Orders**: One-to-Many
5. **Quote → Holdings**: One-to-Many
6. **Order → Holding**: One-to-One (optional, for buy orders)

### Relationship Details

#### Account Relationships
- Each Account has exactly one AccountProfile (1:1)
- Each Account can have multiple Orders (1:N)
- Each Account can have multiple Holdings (1:N)

#### Quote Relationships  
- Each Quote can be referenced by multiple Orders (1:N)
- Each Quote can be referenced by multiple Holdings (1:N)

#### Order-Holding Relationship
- Buy Orders create Holdings (1:1)
- Sell Orders reference existing Holdings (1:1)

### Foreign Key Constraints
While the schema defines foreign key columns, explicit database constraints are not enforced, relying instead on application-level integrity.

## Data Access Patterns

### 1. JPA Access Pattern
Primary data access uses JPA with these characteristics:
- **Entity Manager**: Container-managed, injected via `@PersistenceContext`
- **Transaction Management**: Container-managed JTA transactions
- **Lazy Loading**: Configured for collections (orders, holdings)
- **Eager Loading**: Quote data in orders and holdings
- **Named Queries**: Pre-defined JPQL queries for common operations

### 2. Direct JDBC Pattern
Alternative implementation provides:
- **Connection Management**: DataSource lookup via JNDI
- **Key Generation**: Manual sequence management via KEYGENEJB
- **Transaction Control**: Programmatic transaction management
- **Performance**: Potentially faster for simple operations

### 3. Query Patterns

#### Common Queries
```java
// Find account with profile (eager fetch)
@NamedQuery(name = "accountejb.findByAccountid_eager", 
    query = "SELECT a FROM accountejb a LEFT JOIN FETCH a.profile WHERE a.accountID = :accountid")

// Get user's holdings
@NamedQuery(name = "holdingejb.holdingsByUserID", 
    query = "SELECT h FROM holdingejb h where h.account.profile.userID = :userID")

// Find closed orders for user
@NamedQuery(name = "orderejb.closedOrders", 
    query = "SELECT o FROM orderejb o WHERE o.orderStatus = 'closed' AND o.account.profile.userID = :userID")
```

### 4. Transaction Boundaries
- **Service Layer**: All TradeServices methods run in transactions
- **Message-Driven Beans**: Each message processed in separate transaction
- **Web Tier**: No transactions, relies on service layer

## Performance Considerations

### Indexes
Strategic indexes support common access patterns:
- Account lookup by user ID
- Holdings by account
- Orders by account and status
- Order-holding relationships

### Caching
- JPA L2 caching available but disabled by default
- No application-level caching implemented
- Database connection pooling for performance

### Potential Bottlenecks
1. **No pagination**: Large portfolios load all holdings
2. **Eager fetching**: Quote data always loaded with orders/holdings
3. **Plain text passwords**: Security and compliance issue
4. **No archival**: Historical data accumulates indefinitely

## Data Integrity

### Application-Enforced Rules
1. Account balance must not go negative
2. Holdings quantity must be positive
3. Orders must reference valid quotes
4. Completed orders must have completion date

### Missing Constraints
1. No foreign key constraints at database level
2. No check constraints for business rules
3. No unique constraints beyond primary keys
4. No cascading deletes configured

## ER Diagram

The complete entity relationship diagram is available at:
[ER Diagram](../diagrams/er-diagram.mmd)

The diagram shows all entities, attributes, and relationships in the DayTrader data model.

## Migration Considerations

### Modernization Opportunities
1. **Security**: Encrypt passwords, implement proper credential storage
2. **Performance**: Add pagination, optimize eager/lazy loading
3. **Integrity**: Add database constraints, implement audit trails
4. **Scalability**: Consider partitioning for large datasets
5. **Standards**: Update to JPA 3.0, use UUID primary keys

### Data Migration Challenges
1. Plain text passwords need encryption
2. Missing referential integrity may have orphaned records
3. No versioning/timestamps on some entities
4. Potential data quality issues without constraints

## Summary

DayTrader's data model is a straightforward relational design suitable for its demonstration purpose. While functional, it lacks modern security practices (plain text passwords), database-level integrity constraints, and scalability features like pagination. The dual support for JPA and JDBC provides flexibility but adds complexity. Any modernization effort should prioritize security improvements and data integrity constraints.