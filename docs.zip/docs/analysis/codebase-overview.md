# DayTrader 3 - Codebase Overview

## Executive Summary

DayTrader 3 is a Java EE 6 benchmark application that simulates an online stock trading system. It was developed by IBM as part of the WebSphere Application Server (WAS) Liberty samples to demonstrate the capabilities of enterprise Java technologies.

## Technology Stack

### Core Technologies

- **Platform**: Java EE 6 (Enterprise Edition)
- **Language**: Java 7
- **Application Server**: WebSphere Liberty Profile
- **Build Tools**: 
  - Maven 3.x (Primary)
  - Gradle (Secondary, minimal configuration)

### Framework and API Versions

| Technology | Version | Purpose |
|------------|---------|---------|
| EJB | 3.1 (Lite) | Business logic and session management |
| JPA | 2.0 | Object-relational mapping |
| JSF | 2.0 | Component-based UI framework |
| Servlets | 3.0 | HTTP request handling |
| JSP | 2.1 | View layer templating |
| JAX-RS | 1.1 | RESTful web services |
| JMS | 1.1 | Asynchronous messaging |
| JTA | 1.1 | Transaction management |
| JDBC | 4.2 | Database connectivity |

### Database

- **Primary Database**: Apache Derby 10.10.1.1 (Embedded mode)
- **Additional Support**: Scripts provided for DB2 and Oracle
- **Connection Pooling**: Configured with min 10, max 70 connections

### Messaging Infrastructure

- **Message Broker**: WebSphere embedded JMS server
- **Queue**: TradeBrokerQueue (for order processing)
- **Topic**: TradeStreamerTopic (for market updates)
- **Delivery Mode**: Non-persistent for performance

## Project Structure

### Module Organisation

The application follows a multi-module Maven structure:

```
daytrader3/
├── daytrader3-ee6-ejb/      # Business logic and data access layer
├── daytrader3-ee6-web/      # Web presentation layer
├── daytrader3-ee6-rest/     # RESTful services module
├── daytrader3-ee6/          # EAR packaging module
└── daytrader3-ee6-wlpcfg/   # Liberty server configuration
```

### Module Dependencies

- **Web Module** → depends on → **EJB Module**
- **EAR Module** → packages → **All modules**
- **Server Config** → deploys → **EAR Module**

### Package Structure

Primary package namespace: `com.ibm.websphere.samples.daytrader`

Key sub-packages:
- `direct/` - Direct JDBC implementation
- `ejb3/` - EJB 3.x components
- `util/` - Utility classes
- `web/` - Servlets and web components
- `web.jsf/` - JSF managed beans
- `web.prims/` - Performance testing primitives
- `rest/` - REST service implementations

## Configuration Management

### Build Configuration

- **Parent POM**: `net.wasdev.maven.parent:java7-parent:1.3`
- **Group ID**: `net.wasdev.wlp.sample`
- **Artifact ID**: `daytrader3`
- **Version**: `1.0-SNAPSHOT`
- **Packaging**: Multi-module with EAR deployment

### Runtime Configuration

- **Server Config**: `server.xml` in Liberty profile
- **HTTP Port**: 9083
- **HTTPS Port**: 9443
- **Context Root**: `/daytrader3`
- **Session Management**: Server-managed
- **Transaction Isolation**: TRANSACTION_READ_COMMITTED

### Persistence Configuration

- **Persistence Unit**: "daytrader"
- **Transaction Type**: JTA
- **Entity Classes**:
  - AccountDataBean
  - AccountProfileDataBean
  - HoldingDataBean
  - OrderDataBean
  - QuoteDataBean
- **Caching**: L2 cache disabled by default

## Project Statistics

### File Counts

| File Type | Count |
|-----------|-------|
| Java files | 75 |
| JSP files | 24 |
| XML files | 21 |
| HTML files | 7 |
| Properties files | 2 |
| SQL/DDL files | 4 |

### Code Volume

- **Total Java LOC**: 14,585 lines
- **Number of Modules**: 5
- **Total Entities**: 5 JPA entities
- **Total Servlets**: ~25 servlets
- **Total EJBs**: 6 EJB components

### Component Distribution

| Component Type | Count | Description |
|----------------|-------|-------------|
| Entity Beans | 5 | JPA entities for domain model |
| Session Beans | 2 | Business logic EJBs |
| Message-Driven Beans | 2 | Async order processing |
| Servlets | 25+ | HTTP request handlers |
| JSF Beans | 2 | Managed beans for JSF |
| REST Resources | 3 | RESTful service endpoints |

## Key Directories

### Source Directories

- `/app/daytrader3-ee6-ejb/src/main/java/` - EJB and business logic
- `/app/daytrader3-ee6-web/src/main/java/` - Web tier components
- `/app/daytrader3-ee6-web/src/main/webapp/` - Web resources (JSP, HTML, CSS)
- `/app/daytrader3-ee6-rest/src/main/java/` - REST services

### Configuration Directories

- `/app/daytrader3-ee6-ejb/src/main/resources/META-INF/` - EJB deployment descriptors
- `/app/daytrader3-ee6-web/src/main/webapp/WEB-INF/` - Web deployment descriptors
- `/app/daytrader3-ee6-wlpcfg/servers/` - Liberty server configuration

### Database Scripts

- `/app/daytrader3-ee6-web/src/main/webapp/dbscripts/` - DDL scripts for different databases

## Technology Profile

### Architecture Pattern
- **Pattern**: Traditional 3-tier Java EE architecture
- **Layers**: Presentation (Web) → Business (EJB) → Data (JPA)
- **Deployment**: Single EAR file deployment

### Performance Features
- **Connection Pooling**: Pre-configured for optimal performance
- **Statement Caching**: 60 statements cached
- **Non-persistent Messaging**: For faster message throughput
- **HTTP Keep-Alive**: Enabled with unlimited requests

### Security
- **Authentication**: Form-based authentication
- **Authorization**: Java EE role-based security
- **Data Source Auth**: Configured credentials for database access

## Entry Points

### Web Entry Points
- **Main Application**: `/daytrader3/` (index.html)
- **Trading Interface**: `/daytrader3/app` (TradeAppServlet)
- **Configuration**: `/daytrader3/config` (TradeConfigServlet)
- **Admin Functions**: `/daytrader3/admin` (TradeBuildDB)

### Service Entry Points
- **REST API**: `/daytrader3/rest/*` (JAX-RS endpoints)
- **SOAP Services**: TradeWSAction (if enabled)

### Messaging Entry Points
- **Order Queue**: TradeBrokerQueue (JMS)
- **Market Updates**: TradeStreamerTopic (JMS)

## Build and Deployment

### Build Commands
```bash
# Maven build
mvn clean package

# Gradle build (limited support)
gradle build
```

### Deployment Structure
```
daytrader3-ee6.ear
├── META-INF/
│   └── application.xml
├── dt-ejb.jar
├── web.war
└── lib/
    └── (shared libraries)
```

## Development Environment

### IDE Support
- Eclipse project files configured via Gradle
- Maven integration for dependency management

### Testing Infrastructure
- JMeter test files included (`/jmeter_files/`)
- Performance testing servlets (PingServlet variants)
- Database initialization utilities

## Summary

DayTrader 3 represents a classic Java EE 6 application architecture, demonstrating best practices from the early 2010s era. It provides a comprehensive example of enterprise Java technologies working together, including:

- Stateless session beans for business logic
- JPA entities for data persistence
- Message-driven beans for asynchronous processing
- JSF and JSP for web presentation
- JAX-RS for RESTful services
- Complete transaction management
- Configured connection pooling and performance optimizations

The application serves as both a functional stock trading simulation and a performance benchmark for Java EE application servers, particularly WebSphere Liberty.