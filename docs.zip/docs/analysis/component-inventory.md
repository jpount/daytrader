# DayTrader 3 - Component Inventory

## Overview

This document provides a comprehensive inventory of all components in the DayTrader 3 application, categorized by architectural role and module. The application consists of 75 Java classes distributed across three main modules.

## Module Summary

| Module | Component Count | Primary Purpose |
|--------|----------------|-----------------|
| EJB Module | 27 | Business logic, data access, and messaging |
| Web Module | 43 | Web UI, servlets, and testing primitives |
| REST Module | 6 | RESTful web services |
| **Total** | **76** | |

## Components by Architectural Layer

### 1. Data Access Layer (Entities and Persistence)

#### JPA Entities (5 entities)
| Component | Package | Module | Annotations | Purpose |
|-----------|---------|--------|-------------|---------|
| AccountDataBean | com.ibm.websphere.samples.daytrader | EJB | @Entity, @Table(accountejb) | User account entity with balance and profile |
| AccountProfileDataBean | com.ibm.websphere.samples.daytrader | EJB | @Entity, @Table(accountprofileejb) | User profile information |
| HoldingDataBean | com.ibm.websphere.samples.daytrader | EJB | @Entity, @Table(holdingejb) | Stock holdings for accounts |
| OrderDataBean | com.ibm.websphere.samples.daytrader | EJB | @Entity, @Table(orderejb) | Buy/sell order transactions |
| QuoteDataBean | com.ibm.websphere.samples.daytrader | EJB | @Entity, @Table(quoteejb), @NamedQuery | Stock quote information |

#### Direct JDBC Components (2 classes)
| Component | Package | Module | Purpose |
|-----------|---------|--------|---------|
| TradeDirect | com.ibm.websphere.samples.daytrader.direct | EJB | Direct JDBC implementation of TradeServices |
| KeySequenceDirect | com.ibm.websphere.samples.daytrader.direct | EJB | Key generation for direct JDBC mode |

### 2. Business Logic Layer

#### EJB Components (6 components)
| Component | Package | Module | Type | Annotations | Purpose |
|-----------|---------|--------|------|-------------|---------|
| TradeSLSBBean | com.ibm.websphere.samples.daytrader.ejb3 | EJB | Stateless Session Bean | @Stateless | Main business logic implementation |
| TradeSLSBLocal | com.ibm.websphere.samples.daytrader.ejb3 | EJB | Local Interface | @Local | Local interface for TradeSLSBBean |
| DirectSLSBBean | com.ibm.websphere.samples.daytrader.ejb3 | EJB | Stateless Session Bean | @Stateless | Direct mode session bean |
| DirectSLSBLocal | com.ibm.websphere.samples.daytrader.ejb3 | EJB | Local Interface | @Local | Local interface for DirectSLSBBean |
| DTBroker3MDB | com.ibm.websphere.samples.daytrader.ejb3 | EJB | Message-Driven Bean | @MessageDriven | Processes trading orders asynchronously |
| DTStreamer3MDB | com.ibm.websphere.samples.daytrader.ejb3 | EJB | Message-Driven Bean | @MessageDriven | Streams market updates |

#### Core Business Interfaces and Implementations (6 components)
| Component | Package | Module | Type | Purpose |
|-----------|---------|--------|------|---------|
| TradeServices | com.ibm.websphere.samples.daytrader | EJB | Interface | Core business interface defining all trade operations |
| TradeAction | com.ibm.websphere.samples.daytrader | EJB | Class | Generic client-side access to trade operations |
| TradeWSServices | com.ibm.websphere.samples.daytrader | EJB | Interface | Web service interface for trade operations |
| TradeWSAction | com.ibm.websphere.samples.daytrader | EJB | Class | Web service implementation adapter |
| MarketSummaryDataBean | com.ibm.websphere.samples.daytrader | EJB | Data Transfer Object | Market summary information |
| MarketSummaryDataBeanWS | com.ibm.websphere.samples.daytrader | EJB | Data Transfer Object | Web service version of market summary |

### 3. Web/Presentation Layer

#### Main Application Servlets (5 servlets)
| Component | Package | Module | Annotations | URL Pattern | Purpose |
|-----------|---------|--------|-------------|-------------|---------|
| TradeAppServlet | com.ibm.websphere.samples.daytrader.web | Web | @WebServlet | /app | Main trading application servlet |
| TradeConfigServlet | com.ibm.websphere.samples.daytrader.web | Web | @WebServlet | /config | Configuration management servlet |
| TradeScenarioServlet | com.ibm.websphere.samples.daytrader.web | Web | @WebServlet | /scenario | Trading scenario testing |
| TradeBuildDB | com.ibm.websphere.samples.daytrader.web | Web | None | N/A | Database initialization |
| TestServlet | com.ibm.websphere.samples.daytrader.web | Web | @WebServlet | /TestServlet | Testing utilities |

#### Web Components (3 components)
| Component | Package | Module | Type | Annotations | Purpose |
|-----------|---------|--------|------|-------------|---------|
| TradeServletAction | com.ibm.websphere.samples.daytrader.web | Web | Action Class | None | Servlet action handler |
| OrdersAlertFilter | com.ibm.websphere.samples.daytrader.web | Web | Filter | @WebFilter | Filters orders for alerts |
| TradeWebContextListener | com.ibm.websphere.samples.daytrader.web | Web | Listener | @WebListener | Application context initialization |

#### JSF Managed Beans (2 beans)
| Component | Package | Module | Annotations | Purpose |
|-----------|---------|--------|-------------|---------|
| AccountBean | com.ibm.websphere.samples.daytrader.web.jsf | Web | @ManagedBean | JSF backing bean for account operations |
| QuoteBean | com.ibm.websphere.samples.daytrader.web.jsf | Web | @ManagedBean | JSF backing bean for quote operations |

#### Performance Testing Primitives (31 servlets)
The web module includes 31 performance testing servlets in the `com.ibm.websphere.samples.daytrader.web.prims` package:

**Basic Primitives:**
- PingServlet - Basic servlet response
- PingServletWriter - PrintWriter test
- PingServlet2Jsp - Servlet to JSP forward
- PingServlet2DB - Direct database access
- PingServlet2Include - Request dispatcher include
- PingServlet2Servlet - Servlet to servlet communication
- PingServlet2PDF - PDF generation test
- PingServlet2JNDI - JNDI lookup test
- PingServletSetContentLength - Content length test

**Session Testing:**
- PingSession1, PingSession2, PingSession3 - Session management tests
- PingSession3Object - Session object storage

**JDBC Testing:**
- PingJDBCRead - JDBC read operations
- PingJDBCWrite - JDBC write operations
- PingJDBCRead2JSP - JDBC to JSP

**EJB3 Integration Testing (14 servlets):**
- PingServlet2Entity - Entity bean access
- PingServlet2Session - Session bean access
- PingServlet2SessionLocal - Local session bean
- PingServlet2MDBQueue - Queue messaging
- PingServlet2MDBTopic - Topic messaging
- PingServlet2TwoPhase - Two-phase commit
- Various CMR and collection tests

### 4. REST/Web Services Layer

| Component | Package | Module | Type | Annotations | Purpose |
|-----------|---------|--------|------|-------------|---------|
| AddressApplication | com.ibm.websphere.samples.daytrader.rest | REST | JAX-RS Application | extends Application | REST application configuration |
| AddressBook | com.ibm.websphere.samples.daytrader.rest | REST | REST Resource | @Path("/addresses") | Address book REST service |
| Address | com.ibm.websphere.samples.daytrader.rest | REST | Entity/Resource | @GET | Individual address resource |
| AddressList | com.ibm.websphere.samples.daytrader.rest | REST | Collection DTO | None | Address collection wrapper |
| AddressBookDatabase | com.ibm.websphere.samples.daytrader.rest | REST | Data Store | None | In-memory address storage |
| ObjectFactory | com.ibm.websphere.samples.daytrader.rest | REST | Factory | None | JAXB object factory |

### 5. Utility Components

| Component | Package | Module | Purpose |
|-----------|---------|--------|---------|
| TradeConfig | com.ibm.websphere.samples.daytrader | EJB | Global configuration management |
| RunStatsDataBean | com.ibm.websphere.samples.daytrader | EJB | Runtime statistics collection |
| FinancialUtils | com.ibm.websphere.samples.daytrader.util | EJB | Financial calculations (random price generation) |
| Log | com.ibm.websphere.samples.daytrader.util | EJB | Logging utility |
| MDBStats | com.ibm.websphere.samples.daytrader.util | EJB | Message-driven bean statistics |
| TimerStat | com.ibm.websphere.samples.daytrader.util | EJB | Performance timing utilities |
| KeyBlock | com.ibm.websphere.samples.daytrader.util | EJB | Key generation block management |
| PingBean | com.ibm.websphere.samples.daytrader.web.prims | Web | Testing utility bean |
| ExplicitGC | com.ibm.websphere.samples.daytrader.web.prims | Web | Garbage collection testing |

## Component Dependencies

### Key Dependency Patterns

1. **Web → EJB Dependencies:**
   - TradeAppServlet → TradeAction → TradeSLSBLocal/DirectSLSBLocal
   - JSF Beans → TradeAction → EJB Layer

2. **EJB Internal Dependencies:**
   - TradeSLSBBean → JPA Entities (all 5 entities)
   - TradeSLSBBean → JMS (for DTBroker3MDB, DTStreamer3MDB)
   - DirectSLSBBean → TradeDirect → Direct JDBC

3. **Message-Driven Bean Dependencies:**
   - DTBroker3MDB → TradeSLSBLocal (order processing)
   - DTStreamer3MDB → JMS Topic (market updates)

4. **Configuration Dependencies:**
   - All components → TradeConfig (runtime configuration)
   - All components → Log (logging)

## Entry Points

### Primary Entry Points
1. **Web UI:** `/daytrader3/app` (TradeAppServlet)
2. **Configuration:** `/daytrader3/config` (TradeConfigServlet)
3. **REST API:** `/daytrader3/rest/addresses` (AddressBook)
4. **Testing:** `/daytrader3/servlet/*` (Various PingServlets)

### Secondary Entry Points
- **JMS:** TradeBrokerQueue (DTBroker3MDB)
- **JMS:** TradeStreamerTopic (DTStreamer3MDB)
- **JSF:** Various .xhtml pages with backing beans

## Technology Usage Summary

| Technology | Component Count | Usage |
|------------|----------------|-------|
| JPA/Entity Beans | 5 | Data persistence |
| Stateless Session Beans | 2 | Business logic |
| Message-Driven Beans | 2 | Asynchronous processing |
| Servlets | 36 | Web tier and testing |
| JAX-RS Resources | 2 | REST services |
| JSF Managed Beans | 2 | JSF backing beans |
| Filters | 1 | Request filtering |
| Listeners | 1 | Context management |

## Package Organization

### Primary Packages
- `com.ibm.websphere.samples.daytrader` - Core domain and entities
- `com.ibm.websphere.samples.daytrader.ejb3` - EJB components
- `com.ibm.websphere.samples.daytrader.direct` - Direct JDBC mode
- `com.ibm.websphere.samples.daytrader.util` - Utilities
- `com.ibm.websphere.samples.daytrader.web` - Web tier
- `com.ibm.websphere.samples.daytrader.web.jsf` - JSF components
- `com.ibm.websphere.samples.daytrader.web.prims` - Performance primitives
- `com.ibm.websphere.samples.daytrader.web.prims.ejb3` - EJB test servlets
- `com.ibm.websphere.samples.daytrader.rest` - REST services

## Summary Statistics

- **Total Components:** 76
- **Entities:** 5
- **EJBs:** 4 (2 SLSBs, 2 MDBs)
- **Servlets:** 36
- **Interfaces:** 4
- **Utility Classes:** 10
- **REST Resources:** 6
- **JSF Beans:** 2
- **Web Components:** 3 (1 filter, 1 listener, 1 action class)